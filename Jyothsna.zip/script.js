document.addEventListener("DOMContentLoaded"), function () {
   
    const propertiesEndpoint = "your_properties_api_endpoint";

    // Fetch properties from the server
    fetch(propertiesEndpoint)
        .then(response = response.json())
        .then(properties ="") };
            // Select the dropdown element
    const selectProperty=document.getElementById("selectProperty");

            // Clear existing options
            selectProperty.innerHTML = "";

            // Populate options with fetched properties
            properties.forEach(property => {
                const option = document.createElement("option");
                option.value = property.property_id;
                option.textContent = property.property_name;
                selectProperty.appendChild(option);
            });
        _catch(error = console.error("Error fetching properties:", error));