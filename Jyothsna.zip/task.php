<?php
// Include your database connection file
include_once('database_connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $brokerName = $_POST["brokerName"];
    $brokerContact = $_POST["brokerContact"];
    $brokerEmail = $_POST["brokerEmail"];
    $brokerExperience = $_POST["brokerExperience"];
    $selectedProperty = $_POST["selectProperty"];
    $brokerCommission = $_POST["brokerCommission"];
    $brokerStatus = $_POST["brokerStatus"];

    // TODO: Validate and sanitize form data

    // Perform database insertion for the broker
    // Replace with your actual database insert query
    $sql = "INSERT INTO brokers (name, contact, email, experience, property_id, commission, status)
            VALUES ('$brokerName', '$brokerContact', '$brokerEmail', $brokerExperience, $selectedProperty, $brokerCommission, $brokerStatus)";

    // Execute the query
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Broker added successfully
        echo "Broker added successfully!";
    } else {
        // Error handling for database insertion failure
        echo "Error adding broker: " . mysqli_error($conn);
    }
} else {
    // Handle non-POST requests
    echo "Invalid request method!";
}
?>
<?php
// Include your database connection file
include_once('database_connection.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $ownerName = $_POST["ownerName"];
    $ownerContact = $_POST["ownerContact"];
    $address = $_POST["address"];
    $city = $_POST["city"];
    $zipCode = $_POST["zipCode"];
    $kindOfProperty = $_POST["kindOfProperty"];
    $area = $_POST["area"];
    $totalValuation = $_POST["totalValuation"];
    $propertyStatus = $_POST["propertyStatus"];

    // TODO: Validate and sanitize form data

    // Perform database insertion for the property
    // Replace with your actual database insert query
    $sql = "INSERT INTO properties (owner_name, owner_contact, address, city, zip_code, kind_of_property, area, total_valuation, status)
            VALUES ('$ownerName', '$ownerContact', '$address', '$city', '$zipCode', '$kindOfProperty', $area, $totalValuation, $propertyStatus)";

    // Execute the query
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Property added successfully
        echo "Property added successfully!";
    } else {
        // Error handling for database insertion failure
        echo "Error adding property: " . mysqli_error($conn);
    }
} else {
    // Handle non-POST requests
    echo "Invalid request method!";
}
?>